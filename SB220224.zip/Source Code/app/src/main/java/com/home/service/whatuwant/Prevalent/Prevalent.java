package com.home.service.whatuwant.Prevalent;

import com.home.service.whatuwant.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser;
}
